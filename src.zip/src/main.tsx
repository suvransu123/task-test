import ReactDOM from 'react-dom/client'
import { RouterProvider, createRouter } from '@tanstack/react-router'
import { routeTree } from './routeTree.gen'
import { authService } from './services/auth.service'

const router = createRouter({
  routeTree,
  context: {
    auth: authService,
  },
  scrollRestoration: true,
  defaultPreload: false,
  defaultPreloadStaleTime: 10000,
})

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router
  }
}

const rootElement = document.getElementById('app')!

if (!rootElement.innerHTML) {
  const root = ReactDOM.createRoot(rootElement)
  root.render(<RouterProvider router={router} />)
}
